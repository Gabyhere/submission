import LoginPresenter from './presenters/login-presenter.js';
import RegisterPresenter from './presenters/register-presenter.js';
import HomePresenter from './presenters/home-presenter.js';
import AddPresenter from './presenters/add-presenter.js';
import AboutPresenter from './presenters/about-presenter.js';
import { useViewTransition } from './utils/view-transition.js';
import { stopCamera } from './utils/camera.js';
import '../styles/styles.css';

const loginPresenter = new LoginPresenter();
const registerPresenter = new RegisterPresenter();
const homePresenter = new HomePresenter();
const addPresenter = new AddPresenter();
const aboutPresenter = new AboutPresenter();

const routes = {
  '#/login': () => loginPresenter.show(),
  '#/register': () => registerPresenter.show(),
  '#/home': () => homePresenter.show(),
  '#/add': () => addPresenter.show(),
  '#/about': () => aboutPresenter.show(),
};

function isLoggedIn() {
  return !!localStorage.getItem('token');
}

function router() {
  stopCamera();

  const path = window.location.hash || '#/login';

  if (!isLoggedIn() && path !== '#/login' && path !== '#/register') {
    location.hash = '#/login';
    return;
  }

  if (isLoggedIn() && (path === '#/login' || path === '#/register')) {
    location.hash = '#/home';
    return;
  }

  const render = routes[path] || (() => loginPresenter.show());

  useViewTransition(() => {
    render();
  });
}

// Logout
window.addEventListener('click', (e) => {
  if (e.target.id === 'logout-btn') {
    localStorage.removeItem('token');
    location.hash = '#/login';
  }
});

// Skip Link dan Drawer
window.addEventListener('DOMContentLoaded', () => {
  const skipLink = document.getElementById('skip-link');
  const mainContent = document.getElementById('main-content');
  if (skipLink && mainContent) {
    skipLink.addEventListener('click', (e) => {
      e.preventDefault();
      skipLink.blur();
      mainContent.setAttribute('tabindex', '-1');
      mainContent.focus();
      mainContent.scrollIntoView();
    });
  }

  const drawerButton = document.getElementById('drawer-button');
  const navigationDrawer = document.getElementById('navigation-drawer');
  drawerButton?.addEventListener('click', () => {
    navigationDrawer.classList.toggle('open');
  });
});

// Hash Routing
window.addEventListener('hashchange', router);
window.addEventListener('DOMContentLoaded', router);

// Service Worker & Push Notification
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service-worker.js')
    .then(async (registration) => {
      console.log('Service Worker registered:', registration.scope);

      const vapidKey = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';
      const applicationServerKey = urlBase64ToUint8Array(vapidKey);

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey,
      });

      console.log('Push Subscription:', JSON.stringify(subscription));
    })
    .catch((error) => {
      console.error('Service Worker registration failed:', error);
    });
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

